import json, math, random
from pathlib import Path
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, Ellipse, Line, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.widget import Widget
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout

WORLD_W, WORLD_H = 3000, 2400
SAVE_PATH = Path("savegame.json")

def clamp(v, a, b):
    return max(a, min(b, v))

class GameView(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player = [500.0, 500.0]
        self.cash, self.health = 250, 100
        self.vehicle = None
        self.vehicles = [[430.,520.,0.,0.], [760.,260.,0.,0.], [1120.,650.,0.,0.],
                         [1450.,380.,0.,0.], [1850.,900.,0.,0.], [2200.,1200.,0.,0.]]
        self.peds = [[random.randint(100,WORLD_W-100), random.randint(100,WORLD_H-100)]
                     for _ in range(28)]
        self.police, self.wanted = [], 0
        self.mission_active, self.missions_done = False, 0
        self.mission_start, self.destination = [500.,500.], [900.,500.]
        self.message = "Explore the city. Tap MISSION to begin."
        self.message_time = 5
        self.joy = [0.,0.]
        self.drive = [0.,0.]
        self.touch_roles = {}
        self.font_size = dp(14)
        Clock.schedule_interval(self.update, 1/60)

    def say(self, msg):
        self.message, self.message_time = msg, 3.5

    def on_touch_down(self, touch):
        x, y = touch.x, touch.y
        w, h = self.width, self.height
        # Left lower joystick region
        if x < w*0.43 and y < h*0.48:
            self.touch_roles[touch.uid] = "joy"
            self._set_joy(x, y)
        # Right side driving/action controls
        elif x > w*0.58 and y < h*0.48:
            if x > w*0.82 and y < h*0.20:
                self.touch_roles[touch.uid] = "brake"
                self.drive[1] = -1
            elif x > w*0.82:
                self.touch_roles[touch.uid] = "gas"
                self.drive[1] = 1
            elif x > w*0.68:
                self.touch_roles[touch.uid] = "right"
                self.drive[0] = 1
            else:
                self.touch_roles[touch.uid] = "left"
                self.drive[0] = -1
        return True

    def on_touch_move(self, touch):
        role = self.touch_roles.get(touch.uid)
        if role == "joy":
            self._set_joy(touch.x, touch.y)
        return True

    def on_touch_up(self, touch):
        role = self.touch_roles.pop(touch.uid, None)
        if role == "joy":
            self.joy = [0.,0.]
        elif role in ("gas","brake"):
            self.drive[1] = 0
        elif role in ("left","right"):
            self.drive[0] = 0
        return True

    def _set_joy(self, x, y):
        cx, cy = self.width*0.20, self.height*0.23
        dx, dy = (x-cx)/(self.width*0.13), (y-cy)/(self.height*0.17)
        mag = math.hypot(dx,dy)
        if mag > 1:
            dx,dy = dx/mag,dy/mag
        self.joy = [dx,dy]

    def action(self, name):
        if name == "vehicle":
            if self.vehicle is not None:
                self.vehicle = None
                self.say("Exited vehicle.")
            else:
                nearest = min(self.vehicles, key=lambda v: math.hypot(v[0]-self.player[0],v[1]-self.player[1]))
                if math.hypot(nearest[0]-self.player[0],nearest[1]-self.player[1]) < 85:
                    self.vehicle = nearest
                    self.say("Vehicle entered. Use right-side controls.")
                else:
                    self.say("No vehicle nearby.")
        elif name == "mission":
            if not self.mission_active:
                self.mission_active = True
                self.say("Mission started: reach the yellow marker.")
            elif math.hypot(self.player[0]-self.destination[0],self.player[1]-self.destination[1]) < 75:
                self.complete_mission()
            else:
                self.say("Reach the yellow marker.")
        elif name == "save":
            data = {"player":self.player,"cash":self.cash,"health":self.health,
                    "missions_done":self.missions_done}
            SAVE_PATH.write_text(json.dumps(data), encoding="utf-8")
            self.say("Game saved.")
        elif name == "load":
            if SAVE_PATH.exists():
                data=json.loads(SAVE_PATH.read_text(encoding="utf-8"))
                self.player=data.get("player",[500,500]); self.cash=data.get("cash",250)
                self.health=data.get("health",100); self.missions_done=data.get("missions_done",0)
                self.vehicle=None; self.say("Game loaded.")
            else:
                self.say("No save found.")

    def complete_mission(self):
        self.cash += 500
        self.missions_done += 1
        self.mission_active = False
        self.destination = [(self.destination[0]+620)%WORLD_W, (self.destination[1]+410)%WORLD_H]
        self.say("Mission complete! +$500")

    def update(self, dt):
        dt = min(dt, 0.05)
        if self.vehicle is None:
            dx,dy=self.joy
            self.player[0]=clamp(self.player[0]+dx*230*dt,15,WORLD_W-15)
            self.player[1]=clamp(self.player[1]+dy*230*dt,15,WORLD_H-15)
        else:
            car=self.vehicle
            car[3] = clamp(car[3] + self.drive[1]*320*dt, -100, 390)
            car[3] *= 0.985 ** (dt*60)
            car[2] += self.drive[0]*115*dt*(1 if car[3]>=0 else -1)
            a=math.radians(car[2])
            nx=car[0]+math.cos(a)*car[3]*dt
            ny=car[1]+math.sin(a)*car[3]*dt
            if self._road(nx,ny):
                car[0],car[1]=nx,ny
            else:
                car[3]*=-0.2
            self.player=[car[0],car[1]]
        for p in self.peds:
            if random.random()<0.018:
                p[0]=clamp(p[0]+random.randint(-24,24),0,WORLD_W)
                p[1]=clamp(p[1]+random.randint(-24,24),0,WORLD_H)
        for cop in self.police:
            dx,dy=self.player[0]-cop[0],self.player[1]-cop[1]
            d=max(1,math.hypot(dx,dy))
            cop[0]+=dx/d*105*dt; cop[1]+=dy/d*105*dt
        if self.mission_active and math.hypot(self.player[0]-self.destination[0],self.player[1]-self.destination[1])<65:
            self.complete_mission()
        self.message_time=max(0,self.message_time-dt)
        self.draw_world()

    def _road(self,x,y):
        return (int(x)%360 < 76) or (int(y)%360 < 76)

    def draw_world(self):
        self.canvas.clear()
        w,h=self.width,self.height
        px,py=self.player
        scale=min(w/850,h/600)
        scale=max(0.15,scale)
        ox=w/2-px*scale; oy=h/2-py*scale
        def sx(x): return ox+x*scale
        def sy(y): return oy+y*scale
        with self.canvas:
            Color(0.16,0.29,0.19,1); Rectangle(pos=self.pos,size=self.size)
            # Roads and blocks: repeat across visible world region
            x0=max(0,int((px-w/scale/2)//360)*360-360)
            x1=min(WORLD_W,int((px+w/scale/2)//360+2)*360)
            y0=max(0,int((py-h/scale/2)//360)*360-360)
            y1=min(WORLD_H,int((py+h/scale/2)//360+2)*360)
            Color(0.20,0.21,0.23,1)
            for x in range(x0,x1,360):
                Rectangle(pos=(sx(x),sy(y0)),size=(76*scale,(y1-y0)*scale))
            for y in range(y0,y1,360):
                Rectangle(pos=(sx(x0),sy(y)),size=((x1-x0)*scale,76*scale))
            # Buildings in each city block
            Color(0.43,0.41,0.39,1)
            for x in range(x0,x1,360):
                for y in range(y0,y1,360):
                    bx,by=x+105,y+105
                    Rectangle(pos=(sx(bx),sy(by)),size=(205*scale,205*scale))
            # parked cars
            for car in self.vehicles:
                Color(0.72,0.22,0.19,1)
                Rectangle(pos=(sx(car[0])-13*scale,sy(car[1])-8*scale),size=(26*scale,16*scale))
            # pedestrians
            Color(0.88,0.68,0.48,1)
            for p in self.peds:
                Ellipse(pos=(sx(p[0])-4*scale,sy(p[1])-4*scale),size=(8*scale,8*scale))
            # police
            Color(0.20,0.42,0.95,1)
            for cop in self.police:
                Ellipse(pos=(sx(cop[0])-7*scale,sy(cop[1])-7*scale),size=(14*scale,14*scale))
            if self.mission_active:
                Color(1,0.82,0.18,1)
                Line(circle=(sx(self.destination[0]),sy(self.destination[1]),22*scale),width=2)
            if self.vehicle is None:
                Color(0.25,0.95,0.55,1)
                Ellipse(pos=(sx(px)-9*scale,sy(py)-9*scale),size=(18*scale,18*scale))
            # Screen-space overlays
            Color(0.02,0.025,0.035,0.86)
            RoundedRectangle(pos=(dp(10),h-dp(76)),size=(dp(235),dp(65)),radius=[dp(9)])
            Color(1,0.85,0.35,1)
            self._label(f"SA PYTHON  |  ${self.cash}",dp(18),h-dp(39),dp(14))
            Color(1,1,1,1)
            self._label(f"HP {self.health}   MISSIONS {self.missions_done}",dp(18),h-dp(62),dp(11))
            if self.wanted:
                Color(1,0.25,0.22,1)
                self._label("WANTED  "+"★"*self.wanted,w-dp(170),h-dp(39),dp(15))
            # joystick base and knob
            cx,cy=w*0.20,h*0.23
            Color(0.03,0.04,0.06,0.52); Ellipse(pos=(cx-dp(58),cy-dp(58)),size=(dp(116),dp(116)))
            Color(0.85,0.88,0.92,0.48)
            Ellipse(pos=(cx+ self.joy[0]*dp(30)-dp(24),cy+self.joy[1]*dp(30)-dp(24)),size=(dp(48),dp(48)))
            # right-side driving pads
            self._control(w-dp(155),dp(35),dp(62),dp(62),"◀")
            self._control(w-dp(85),dp(35),dp(62),dp(62),"▶")
            self._control(w-dp(85),dp(110),dp(62),dp(62),"▲")
            self._control(w-dp(155),dp(110),dp(62),dp(62),"▼")
            if self.message_time>0:
                Color(0.02,0.025,0.035,0.8)
                RoundedRectangle(pos=(w*0.24,dp(8)),size=(w*0.52,dp(30)),radius=[dp(7)])
                Color(1,1,1,1); self._label(self.message,w*0.26,dp(17),dp(11))

    def _label(self,text,x,y,size):
        lbl=Label(text=text,font_size=size,color=(1,1,1,1),size_hint=(None,None),
                  size=(max(dp(180),len(text)*size*0.7),size*1.8),pos=(x,y))
        lbl.texture_update()
        Rectangle(texture=lbl.texture,pos=lbl.pos,size=lbl.texture.size)

    def _control(self,x,y,w,h,text):
        Color(0.03,0.04,0.06,0.72)
        RoundedRectangle(pos=(x,y),size=(w,h),radius=[dp(12)])
        Color(0.95,0.95,0.98,0.9)
        self._label(text,x+w*0.32,y+h*0.22,dp(24))

class MobileGame(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.view=GameView(size_hint=(1,1))
        self.add_widget(self.view)
        # Action bar stays above the joystick / driving pads.
        bar=BoxLayout(orientation="horizontal",size_hint=(None,None),
                      size=(dp(250),dp(42)),pos_hint={"right":0.99,"top":0.99},spacing=dp(4))
        for title,action in [("CAR","vehicle"),("MISSION","mission"),("SAVE","save"),("LOAD","load")]:
            btn=Button(text=title,font_size=dp(11),background_normal="",
                       background_color=(0.45,0.08,0.11,0.94),color=(1,1,1,1))
            btn.bind(on_release=lambda instance,a=action:self.view.action(a))
            bar.add_widget(btn)
        self.add_widget(bar)

class SanAndreasMobileApp(App):
    def build(self):
        self.title="San Andreas Python Edition"
        Window.clearcolor=(0.08,0.09,0.10,1)
        return MobileGame()

if __name__ == "__main__":
    SanAndreasMobileApp().run()
