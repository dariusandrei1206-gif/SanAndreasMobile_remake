# San Andreas Python Edition - Android Mobile Port

A mobile-first, original 2D open-world prototype using Kivy. It includes touch controls, a scrolling city, player movement, cars, pedestrians, police pursuit, a wanted indicator, missions, cash and local save/load.

## Run on desktop for testing
```bash
python -m pip install kivy
python main.py
```

## Build an Android APK
Buildozer requires Linux (Ubuntu recommended), Java, Android SDK/NDK and internet access.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install buildozer cython
buildozer android debug
```

The APK is normally created under `bin/`. Copy it to an Android phone and install it, allowing installation from that source when Android asks.

## Controls
- Left virtual joystick: walk
- Right-side arrows: steer
- Up/down: accelerate/reverse
- CAR: enter/exit nearest vehicle
- MISSION: start mission
- SAVE / LOAD: local progress

## Notes
- This is an original prototype, not the original Rockstar game or its assets.
- This environment did not have Buildozer or the Android SDK installed, so an APK could not be compiled here. The project includes its Android build configuration.
- The mobile prototype is a separate Kivy port, not a direct conversion of the earlier Pygame desktop prototype.
